package com.lockin.app.service

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.lockin.app.LockinApplication
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

/**
 * Genuine Android local loopback VPN service for DNS-based domain filtering.
 *
 * HOW IT WORKS:
 * 1. Establishes a TUN interface capturing DNS traffic directed to virtual gateway 10.0.0.1
 *    as well as popular public DNS resolvers (8.8.8.8, 1.1.1.1).
 * 2. Continuously reads raw IPv4 packets from the TUN descriptor on a non-blocking loop.
 * 3. Extracts UDP packets addressed to destination port 53 (DNS).
 * 4. Parses RFC 1035 QNAME (queried domain name) from the Question section.
 * 5. If domain matches active session's blocklist:
 *    - Immediately synthesizes an in-memory DNS A-Record Sinkhole (0.0.0.0 response).
 *    - Reverses IP/UDP headers and writes back to TUN interface without external network access.
 * 6. If domain is allowed:
 *    - Forwards query asynchronously to upstream public DNS using a protected DatagramSocket.
 *    - Writes the upstream answer back to the local device.
 *
 * KNOWN OS BOUNDARIES (TRANSPARENCY):
 * - Intercepts all standard UDP port 53 DNS traffic across device applications and browsers.
 * - Browsers with DNS-over-HTTPS (DoH / Secure DNS) explicitly enabled (e.g. Chrome / Firefox)
 *   route queries through encrypted HTTPS (port 443). LOCKIN addresses this by pairing this VPN
 *   with AccessibilityService URL bar inspection to intercept navigation to blocked domains.
 */
class LockinVpnFilterService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var workerJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }

        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (vpnInterface != null) return

        try {
            val builder = Builder()
                .setSession("LOCKIN DNS Filter")
                .addAddress("10.0.0.2", 32)
                .addDnsServer(DNS_GATEWAY)
                .addRoute(DNS_GATEWAY, 32)
                .addRoute("8.8.8.8", 32)
                .addRoute("1.1.1.1", 32)
                .setMtu(MTU)
                .setBlocking(true)

            vpnInterface = builder.establish()

            workerJob?.cancel()
            workerJob = scope.launch {
                runPacketLoop()
            }
            isRunning = true
            Log.i(TAG, "LOCKIN VPN DNS filter started successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to establish VPN interface", e)
            stopSelf()
        }
    }

    private suspend fun runPacketLoop() = withContext(Dispatchers.IO) {
        val pfd = vpnInterface ?: return@withContext
        val inStream = FileInputStream(pfd.fileDescriptor)
        val outStream = FileOutputStream(pfd.fileDescriptor)
        val packetBuffer = ByteArray(MTU)

        val upstreamDns = InetAddress.getByName(UPSTREAM_DNS_IP)
        val repository = LockinApplication.instance.repository

        try {
            while (isActive) {
                val length = inStream.read(packetBuffer)
                if (length <= 0) continue

                // Verify IPv4
                val version = (packetBuffer[0].toInt() shr 4) and 0x0F
                if (version != 4) continue

                val ihl = (packetBuffer[0].toInt() and 0x0F) * 4
                if (ihl < 20 || length < ihl + 8) continue

                val protocol = packetBuffer[9].toInt() and 0xFF
                if (protocol != 17) { // 17 = UDP
                    continue
                }

                val srcPort = ((packetBuffer[ihl].toInt() and 0xFF) shl 8) or (packetBuffer[ihl + 1].toInt() and 0xFF)
                val dstPort = ((packetBuffer[ihl + 2].toInt() and 0xFF) shl 8) or (packetBuffer[ihl + 3].toInt() and 0xFF)

                // Only intercept DNS queries (dest port 53)
                if (dstPort != 53) continue

                val udpPayloadOffset = ihl + 8
                val udpPayloadLength = length - udpPayloadOffset
                if (udpPayloadLength < 12) continue // Min DNS header is 12 bytes

                val dnsData = packetBuffer.copyOfRange(udpPayloadOffset, length)
                val queryDomain = extractQueryDomain(dnsData)

                val session = repository.currentSession.value
                val isSessionActive = session != null && session.isActive && !session.isExpired

                val isBlocked = if (isSessionActive && queryDomain != null) {
                    isDomainBlocked(queryDomain, session!!.blockedDomains)
                } else false

                if (isBlocked) {
                    Log.d(TAG, "DNS SINKHOLE INTERCEPTED: $queryDomain -> 0.0.0.0")
                    // Synthesize 0.0.0.0 A-record answer
                    val responseDns = buildSinkholeResponse(dnsData)
                    val responseIpPacket = buildIpUdpPacket(
                        originalPacket = packetBuffer,
                        srcPort = srcPort,
                        dstPort = dstPort,
                        payload = responseDns
                    )
                    synchronized(outStream) {
                        outStream.write(responseIpPacket)
                        outStream.flush()
                    }
                } else {
                    // Forward query asynchronously to prevent blocking the TUN read loop
                    val packetCopy = packetBuffer.copyOf(length)
                    scope.launch(Dispatchers.IO) {
                        forwardUpstreamQuery(packetCopy, dnsData, srcPort, dstPort, upstreamDns, outStream)
                    }
                }
            }
        } catch (e: Exception) {
            if (isActive) {
                Log.e(TAG, "Error in packet loop", e)
            }
        }
    }

    /**
     * Forwards allowed DNS query to upstream DNS resolver using a protected DatagramSocket.
     */
    private fun forwardUpstreamQuery(
        originalPacket: ByteArray,
        dnsData: ByteArray,
        srcPort: Int,
        dstPort: Int,
        upstreamDns: InetAddress,
        outStream: FileOutputStream
    ) {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            protect(socket)
            socket.soTimeout = 2000

            val sendPacket = DatagramPacket(dnsData, dnsData.size, upstreamDns, 53)
            socket.send(sendPacket)

            val recvBuf = ByteArray(MTU)
            val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
            socket.receive(recvPacket)

            val responseDns = recvBuf.copyOf(recvPacket.length)
            val responseIpPacket = buildIpUdpPacket(
                originalPacket = originalPacket,
                srcPort = srcPort,
                dstPort = dstPort,
                payload = responseDns
            )

            synchronized(outStream) {
                outStream.write(responseIpPacket)
                outStream.flush()
            }
        } catch (e: Exception) {
            // Upstream timeout or network error - drop packet silently
        } finally {
            try {
                socket?.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    /**
     * Extracts query domain name according to RFC 1035 wire format.
     */
    private fun extractQueryDomain(dnsPayload: ByteArray): String? {
        if (dnsPayload.size < 12) return null
        var offset = 12 // Skip DNS header
        val sb = StringBuilder()

        while (offset < dnsPayload.size) {
            val labelLen = dnsPayload[offset].toInt() and 0xFF
            if (labelLen == 0) break // End of QNAME

            // Pointer compression not expected in Question QNAME, but guard against malformed
            if ((labelLen and 0xC0) == 0xC0) break

            offset++
            if (offset + labelLen > dnsPayload.size) return null

            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dnsPayload, offset, labelLen, Charsets.US_ASCII))
            offset += labelLen
        }

        return if (sb.isNotEmpty()) sb.toString().lowercase() else null
    }

    private fun isDomainBlocked(queryDomain: String, blockedDomains: Set<String>): Boolean {
        for (blocked in blockedDomains) {
            val cleanBlocked = blocked.trim().lowercase()
            if (queryDomain == cleanBlocked || queryDomain.endsWith(".$cleanBlocked")) {
                return true
            }
        }
        return false
    }

    /**
     * Synthesizes a valid RFC 1035 DNS response with an A-record answering 0.0.0.0 (Sinkhole).
     * Returning 0.0.0.0 with TTL 60 causes browser TCP connections to fail immediately
     * without triggering unwanted search engine fallbacks.
     */
    private fun buildSinkholeResponse(queryDns: ByteArray): ByteArray {
        if (queryDns.size < 12) return queryDns

        // Find end of Question section (QNAME + QTYPE(2) + QCLASS(2))
        var offset = 12
        while (offset < queryDns.size) {
            val len = queryDns[offset].toInt() and 0xFF
            if (len == 0) {
                offset += 5 // Skip 0x00 terminal byte + 2 bytes QTYPE + 2 bytes QCLASS
                break
            }
            if ((len and 0xC0) == 0xC0) {
                offset += 6 // Pointer + QTYPE + QCLASS
                break
            }
            offset += 1 + len
        }

        val questionLen = offset.coerceAtMost(queryDns.size)
        // Answer Record: Name Pointer (2) + Type A (2) + Class IN (2) + TTL 60 (4) + RdLength 4 (2) + IP 0.0.0.0 (4) = 16 bytes
        val answerLen = 16
        val response = ByteArray(questionLen + answerLen)

        // Copy Header & Question
        System.arraycopy(queryDns, 0, response, 0, questionLen)

        // Set Flags: QR=1 (Response), AA=1, RD=1, RA=1, RCODE=0 (No error)
        response[2] = 0x85.toByte() // 1000 0101 (QR, AA, RD)
        response[3] = 0x80.toByte() // 1000 0000 (RA, RCODE=0)

        // Set ANCOUNT = 1 (Answer Count)
        response[6] = 0x00.toByte()
        response[7] = 0x01.toByte()

        // Append Answer Section at questionLen
        var ansOffset = questionLen
        // Name: compression pointer to QNAME at byte 12 (0xC00C)
        response[ansOffset++] = 0xC0.toByte()
        response[ansOffset++] = 0x0C.toByte()
        // Type: A (0x0001)
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x01.toByte()
        // Class: IN (0x0001)
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x01.toByte()
        // TTL: 60 seconds (0x0000003C)
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x3C.toByte()
        // Data length: 4 bytes
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x04.toByte()
        // IP: 0.0.0.0
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset++] = 0x00.toByte()
        response[ansOffset] = 0x00.toByte()

        return response
    }

    /**
     * Reconstructs IPv4 and UDP header with reversed addresses/ports and appends payload.
     */
    private fun buildIpUdpPacket(
        originalPacket: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val totalIpLen = 20 + 8 + payload.size
        val packet = ByteArray(totalIpLen)

        // 1. IP Header (20 bytes)
        packet[0] = 0x45.toByte() // IPv4, IHL = 5
        packet[1] = 0x00.toByte() // DSCP/ECN
        packet[2] = ((totalIpLen shr 8) and 0xFF).toByte()
        packet[3] = (totalIpLen and 0xFF).toByte()
        packet[4] = 0x00.toByte() // Identification
        packet[5] = 0x01.toByte()
        packet[6] = 0x40.toByte() // Flags: Don't Fragment
        packet[7] = 0x00.toByte()
        packet[8] = 64.toByte()   // TTL
        packet[9] = 17.toByte()   // Protocol: UDP

        // Swap IPs: Original Dest becomes Source, Original Source becomes Dest
        System.arraycopy(originalPacket, 16, packet, 12, 4)
        System.arraycopy(originalPacket, 12, packet, 16, 4)

        // Calculate IP Checksum
        val ipChecksum = calculateChecksum(packet, 0, 20)
        packet[10] = ((ipChecksum shr 8) and 0xFF).toByte()
        packet[11] = (ipChecksum and 0xFF).toByte()

        // 2. UDP Header (8 bytes)
        // Swap Ports: Original Dst becomes Src (53), Original Src becomes Dst
        packet[20] = ((dstPort shr 8) and 0xFF).toByte()
        packet[21] = (dstPort and 0xFF).toByte()
        packet[22] = ((srcPort shr 8) and 0xFF).toByte()
        packet[23] = (srcPort and 0xFF).toByte()

        val udpLen = 8 + payload.size
        packet[24] = ((udpLen shr 8) and 0xFF).toByte()
        packet[25] = (udpLen and 0xFF).toByte()
        packet[26] = 0x00.toByte() // UDP Checksum 0 is valid in IPv4 UDP
        packet[27] = 0x00.toByte()

        // 3. Payload
        System.arraycopy(payload, 0, packet, 28, payload.size)

        return packet
    }

    private fun calculateChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0
        var i = offset
        while (i < offset + length - 1) {
            val high = data[i].toInt() and 0xFF
            val low = data[i + 1].toInt() and 0xFF
            sum += (high shl 8) or low
            i += 2
        }
        if (length % 2 == 1) {
            sum += (data[offset + length - 1].toInt() and 0xFF) shl 8
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return sum.inv() and 0xFFFF
    }

    private fun stopVpn() {
        workerJob?.cancel()
        workerJob = null
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN descriptor", e)
        }
        isRunning = false
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVpn()
        scope.cancel()
    }

    companion object {
        private const val TAG = "LockinVpnFilter"
        private const val MTU = 1500
        private const val DNS_GATEWAY = "10.0.0.1"
        private const val UPSTREAM_DNS_IP = "8.8.8.8"

        const val ACTION_START = "com.lockin.app.START_VPN"
        const val ACTION_STOP = "com.lockin.app.STOP_VPN"

        var isRunning = false
            private set
    }
}

package com.lockin.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.lockin.app.LockinApplication
import com.lockin.app.MainActivity
import kotlinx.coroutines.*

class AppMonitorForegroundService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var tickerJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("LOCKIN is active"))
        startTicker()
        return START_STICKY
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            val repository = LockinApplication.instance.repository
            while (isActive) {
                val session = repository.currentSession.value
                if (session == null || !session.isActive) {
                    stopSelf()
                    break
                }

                if (session.isExpired) {
                    repository.stopSession()
                    stopSelf()
                    break
                }

                val remainingMinutes = (session.remainingMillis / 60000).toInt()
                val remainingSeconds = ((session.remainingMillis % 60000) / 1000).toInt()
                val text = "Blocking ${session.blockedPackages.size} apps • %02d:%02d remaining".format(
                    remainingMinutes,
                    remainingSeconds
                )

                val notificationManager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                notificationManager.notify(NOTIFICATION_ID, buildNotification(text))

                delay(1000)
            }
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, LockinApplication.CHANNEL_ID_PROTECTION)
            .setContentTitle("LOCKIN • Focus Active")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        tickerJob?.cancel()
        scope.cancel()
    }

    companion object {
        const val NOTIFICATION_ID = 1001
    }
}

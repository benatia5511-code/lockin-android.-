package com.lockin.app

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.receiver.LockinDeviceAdminReceiver
import com.lockin.app.service.AppMonitorForegroundService
import com.lockin.app.service.LockinAccessibilityService
import com.lockin.app.service.LockinVpnFilterService
import com.lockin.app.ui.screens.*
import com.lockin.app.ui.theme.*

class MainActivity : ComponentActivity() {

    private val isAccessibilityEnabledState = mutableStateOf(false)

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            startVpnService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LockinTheme {
                val repository = LockinApplication.instance.repository

                val currentSession by repository.currentSession.collectAsState()
                val selectedApps by repository.selectedApps.collectAsState()
                val blockedDomains by repository.blockedDomains.collectAsState()
                val isStrictMode by repository.isStrictMode.collectAsState()
                val isAdminEnabled by repository.isAdminEnabled.collectAsState()
                val isAccessibilityEnabled by isAccessibilityEnabledState

                var currentTab by remember { mutableStateOf("dashboard") }

                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = LockinSurface,
                            tonalElevation = 0.dp
                        ) {
                            listOf(
                                "dashboard" to "Home",
                                "apps" to "Apps",
                                "web" to "Web",
                                "strict" to "Strict",
                                "admin" to "Admin",
                                "settings" to "Settings"
                            ).forEach { (key, title) ->
                                val selected = currentTab == key
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = key },
                                    icon = {
                                        Box(
                                            modifier = Modifier
                                                .size(if (selected) 6.dp else 4.dp)
                                                .background(
                                                    if (selected) LockinCyan else LockinSubtle,
                                                    shape = androidx.compose.foundation.shape.CircleShape
                                                )
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = title,
                                            fontSize = 10.sp,
                                            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
                                            color = if (selected) LockinWhite else LockinGrayText
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = Color.Transparent
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentTab) {
                            "dashboard" -> DashboardScreen(
                                currentSession = currentSession,
                                selectedAppCount = selectedApps.size,
                                blockedDomainCount = blockedDomains.size,
                                isStrictMode = isStrictMode,
                                isAccessibilityEnabled = isAccessibilityEnabled,
                                onRequestAccessibilityPermission = { openAccessibilitySettings() },
                                onStartSessionClick = { durationMinutes ->
                                    if (!isAccessibilityEnabled && selectedApps.isNotEmpty()) {
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Accessibility permission required for real app blocking.",
                                            Toast.LENGTH_LONG
                                        ).show()
                                        openAccessibilitySettings()
                                    } else {
                                        startBlockingSession(
                                            durationMinutes = durationMinutes,
                                            packages = selectedApps,
                                            domains = blockedDomains,
                                            strictMode = isStrictMode,
                                            adminLocked = isAdminEnabled
                                        )
                                    }
                                },
                                onStopSessionClick = {
                                    val stopped = repository.stopSession()
                                    if (stopped) {
                                        stopBlockingServices()
                                    } else {
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Strict Mode active: Early cancellation denied.",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                },
                                onNavigateToApps = { currentTab = "apps" },
                                onNavigateToWebsites = { currentTab = "web" },
                                onNavigateToSettings = { currentTab = "settings" }
                            )

                            "apps" -> AppBlockerScreen(
                                selectedPackages = selectedApps,
                                onTogglePackage = { pkg ->
                                    val updated = if (selectedApps.contains(pkg)) {
                                        selectedApps - pkg
                                    } else {
                                        selectedApps + pkg
                                    }
                                    repository.updateSelectedApps(updated)
                                },
                                onStartSessionWithDuration = { durationMins ->
                                    if (!isAccessibilityEnabled) {
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Accessibility permission required for real app blocking.",
                                            Toast.LENGTH_LONG
                                        ).show()
                                        openAccessibilitySettings()
                                    } else {
                                        startBlockingSession(
                                            durationMinutes = durationMins,
                                            packages = selectedApps,
                                            domains = blockedDomains,
                                            strictMode = isStrictMode,
                                            adminLocked = isAdminEnabled
                                        )
                                        currentTab = "dashboard"
                                    }
                                }
                            )

                            "web" -> WebsiteBlockerScreen(
                                blockedDomains = blockedDomains,
                                onToggleDomain = { domain ->
                                    val updated = if (blockedDomains.contains(domain)) {
                                        blockedDomains - domain
                                    } else {
                                        blockedDomains + domain
                                    }
                                    repository.updateBlockedDomains(updated)
                                },
                                onAddCustomDomain = { domain ->
                                    repository.updateBlockedDomains(blockedDomains + domain)
                                }
                            )

                            "strict" -> StrictModeScreen(
                                isStrictMode = isStrictMode,
                                onToggleStrictMode = { enabled ->
                                    repository.setStrictMode(enabled)
                                }
                            )

                            "admin" -> AdminModeScreen(
                                isAdminEnabled = isAdminEnabled,
                                onSetPin = { pin ->
                                    repository.setAdminPin(pin)
                                },
                                onDisableAdmin = { pin ->
                                    repository.disableAdmin(pin)
                                }
                            )

                            "settings" -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Continuously refresh permission state when returning from system settings
        isAccessibilityEnabledState.value = LockinAccessibilityService.isEnabledInSettings(this)
    }

    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open Accessibility settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startBlockingSession(
        durationMinutes: Int,
        packages: Set<String>,
        domains: Set<String>,
        strictMode: Boolean,
        adminLocked: Boolean
    ) {
        val repository = LockinApplication.instance.repository
        repository.startSession(durationMinutes, packages, domains, strictMode, adminLocked)

        // If strict mode and Device Owner is provisioned, activate real OS uninstall lock
        if (strictMode) {
            LockinDeviceAdminReceiver.setUninstallBlockedIfDeviceOwner(this, true)
        }

        // Launch Foreground monitor service for persistent notification & timer
        val monitorIntent = Intent(this, AppMonitorForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(monitorIntent)
        } else {
            startService(monitorIntent)
        }

        // Launch VPN Filter if website domain blocking is active
        if (domains.isNotEmpty()) {
            val vpnPrepareIntent = VpnService.prepare(this)
            if (vpnPrepareIntent != null) {
                vpnPermissionLauncher.launch(vpnPrepareIntent)
            } else {
                startVpnService()
            }
        }

        Toast.makeText(this, "LOCKIN session active for $durationMinutes minutes", Toast.LENGTH_SHORT).show()
    }

    private fun startVpnService() {
        val vpnIntent = Intent(this, LockinVpnFilterService::class.java).apply {
            action = LockinVpnFilterService.ACTION_START
        }
        startService(vpnIntent)
    }

    private fun stopBlockingServices() {
        // Unlock uninstallation if Device Owner was blocking it
        LockinDeviceAdminReceiver.setUninstallBlockedIfDeviceOwner(this, false)

        stopService(Intent(this, AppMonitorForegroundService::class.java))
        stopService(Intent(this, LockinVpnFilterService::class.java).apply {
            action = LockinVpnFilterService.ACTION_STOP
        })
        Toast.makeText(this, "Session ended.", Toast.LENGTH_SHORT).show()
    }
}

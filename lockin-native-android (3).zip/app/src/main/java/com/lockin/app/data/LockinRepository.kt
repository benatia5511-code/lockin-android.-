package com.lockin.app.data

import android.content.Context
import android.content.SharedPreferences
import com.lockin.app.model.BlockSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

class LockinRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _currentSession = MutableStateFlow<BlockSession?>(null)
    val currentSession: StateFlow<BlockSession?> = _currentSession.asStateFlow()

    private val _selectedApps = MutableStateFlow<Set<String>>(emptySet())
    val selectedApps: StateFlow<Set<String>> = _selectedApps.asStateFlow()

    private val _blockedDomains = MutableStateFlow<Set<String>>(emptySet())
    val blockedDomains: StateFlow<Set<String>> = _blockedDomains.asStateFlow()

    private val _isStrictMode = MutableStateFlow(false)
    val isStrictMode: StateFlow<Boolean> = _isStrictMode.asStateFlow()

    private val _isAdminEnabled = MutableStateFlow(false)
    val isAdminEnabled: StateFlow<Boolean> = _isAdminEnabled.asStateFlow()

    init {
        loadPersistedState()
    }

    private fun loadPersistedState() {
        val appsSet = prefs.getStringSet(KEY_SELECTED_APPS, DEFAULT_APPS) ?: DEFAULT_APPS
        _selectedApps.value = appsSet

        val domainsSet = prefs.getStringSet(KEY_BLOCKED_DOMAINS, DEFAULT_DOMAINS) ?: DEFAULT_DOMAINS
        _blockedDomains.value = domainsSet

        _isStrictMode.value = prefs.getBoolean(KEY_STRICT_MODE, false)
        _isAdminEnabled.value = prefs.getBoolean(KEY_ADMIN_ENABLED, false)

        val sessionJson = prefs.getString(KEY_ACTIVE_SESSION, null)
        if (sessionJson != null) {
            try {
                val json = JSONObject(sessionJson)
                val endTime = json.getLong("endTimeMillis")
                if (System.currentTimeMillis() < endTime) {
                    val packages = mutableSetOf<String>()
                    val pkgArray = json.optJSONArray("blockedPackages")
                    if (pkgArray != null) {
                        for (i in 0 until pkgArray.length()) {
                            packages.add(pkgArray.getString(i))
                        }
                    }

                    val domains = mutableSetOf<String>()
                    val domArray = json.optJSONArray("blockedDomains")
                    if (domArray != null) {
                        for (i in 0 until domArray.length()) {
                            domains.add(domArray.getString(i))
                        }
                    }

                    _currentSession.value = BlockSession(
                        id = json.getString("id"),
                        title = json.optString("title", "Active Focus"),
                        startTimeMillis = json.getLong("startTimeMillis"),
                        endTimeMillis = endTime,
                        durationMinutes = json.getInt("durationMinutes"),
                        blockedPackages = packages,
                        blockedDomains = domains,
                        isStrictMode = json.getBoolean("isStrictMode"),
                        isAdminLocked = json.getBoolean("isAdminLocked"),
                        isActive = true
                    )
                } else {
                    // Session naturally expired
                    clearActiveSession()
                }
            } catch (e: Exception) {
                clearActiveSession()
            }
        }
    }

    fun startSession(
        durationMinutes: Int,
        packages: Set<String>,
        domains: Set<String>,
        strictMode: Boolean,
        adminLocked: Boolean
    ): BlockSession {
        val now = System.currentTimeMillis()
        val endTime = now + (durationMinutes.toLong() * 60 * 1000)
        val session = BlockSession(
            durationMinutes = durationMinutes,
            startTimeMillis = now,
            endTimeMillis = endTime,
            blockedPackages = packages,
            blockedDomains = domains,
            isStrictMode = strictMode,
            isAdminLocked = adminLocked,
            isActive = true
        )

        _currentSession.value = session
        persistSession(session)
        return session
    }

    fun stopSession(adminPin: String? = null): Boolean {
        val session = _currentSession.value ?: return true

        // Strict mode policy check
        if (session.isStrictMode && !session.isExpired) {
            if (session.isAdminLocked) {
                if (adminPin == null || !verifyAdminPin(adminPin)) {
                    return false // Rejected: Admin PIN required
                }
            } else {
                // Strict mode without admin lock forbids cancellation until timer runs out
                return false
            }
        }

        clearActiveSession()
        return true
    }

    private fun persistSession(session: BlockSession) {
        val json = JSONObject().apply {
            put("id", session.id)
            put("title", session.title)
            put("startTimeMillis", session.startTimeMillis)
            put("endTimeMillis", session.endTimeMillis)
            put("durationMinutes", session.durationMinutes)
            put("blockedPackages", JSONArray(session.blockedPackages))
            put("blockedDomains", JSONArray(session.blockedDomains))
            put("isStrictMode", session.isStrictMode)
            put("isAdminLocked", session.isAdminLocked)
        }
        prefs.edit().putString(KEY_ACTIVE_SESSION, json.toString()).apply()
    }

    private fun clearActiveSession() {
        _currentSession.value = null
        prefs.edit().remove(KEY_ACTIVE_SESSION).apply()
    }

    fun updateSelectedApps(apps: Set<String>) {
        _selectedApps.value = apps
        prefs.edit().putStringSet(KEY_SELECTED_APPS, apps).apply()
    }

    fun updateBlockedDomains(domains: Set<String>) {
        _blockedDomains.value = domains
        prefs.edit().putStringSet(KEY_BLOCKED_DOMAINS, domains).apply()
    }

    fun setStrictMode(enabled: Boolean) {
        _isStrictMode.value = enabled
        prefs.edit().putBoolean(KEY_STRICT_MODE, enabled).apply()
    }

    fun setAdminPin(pin: String) {
        val salt = "LOCKIN_SALT_V1"
        val hash = sha256("$salt$pin")
        prefs.edit()
            .putString(KEY_ADMIN_PIN_HASH, hash)
            .putBoolean(KEY_ADMIN_ENABLED, true)
            .apply()
        _isAdminEnabled.value = true
    }

    fun disableAdmin(currentPin: String): Boolean {
        if (verifyAdminPin(currentPin)) {
            prefs.edit()
                .remove(KEY_ADMIN_PIN_HASH)
                .putBoolean(KEY_ADMIN_ENABLED, false)
                .apply()
            _isAdminEnabled.value = false
            return true
        }
        return false
    }

    fun verifyAdminPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_ADMIN_PIN_HASH, null) ?: return false
        val salt = "LOCKIN_SALT_V1"
        return storedHash == sha256("$salt$pin")
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val PREFS_NAME = "lockin_secure_prefs"
        private const val KEY_ACTIVE_SESSION = "key_active_session"
        private const val KEY_SELECTED_APPS = "key_selected_apps"
        private const val KEY_BLOCKED_DOMAINS = "key_blocked_domains"
        private const val KEY_STRICT_MODE = "key_strict_mode"
        private const val KEY_ADMIN_PIN_HASH = "key_admin_pin_hash"
        private const val KEY_ADMIN_ENABLED = "key_admin_enabled"

        val DEFAULT_APPS = setOf(
            "com.zhiliaoapp.musically",       // TikTok
            "com.instagram.android",          // Instagram
            "com.google.android.youtube",     // YouTube
            "com.android.chrome",             // Google Chrome
            "com.reddit.frontpage",           // Reddit
            "com.twitter.android"             // X / Twitter
        )

        val DEFAULT_DOMAINS = setOf(
            "tiktok.com",
            "instagram.com",
            "youtube.com",
            "reddit.com",
            "x.com",
            "twitter.com",
            "twitch.tv"
        )
    }
}

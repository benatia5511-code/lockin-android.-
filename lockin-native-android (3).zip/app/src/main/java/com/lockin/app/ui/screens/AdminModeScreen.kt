package com.lockin.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.ui.theme.*

@Composable
fun AdminModeScreen(
    isAdminEnabled: Boolean,
    onSetPin: (String) -> Unit,
    onDisableAdmin: (String) -> Boolean
) {
    val scrollState = rememberScrollState()

    var showPinSetupDialog by remember { mutableStateOf(false) }
    var showDisableDialog by remember { mutableStateOf(false) }

    var pinInput by remember { mutableStateOf("") }
    var pinConfirmInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var disablePinInput by remember { mutableStateOf("") }
    var disableError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LockinBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Trusted Partner",
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            color = LockinWhite
        )

        Text(
            text = "Delegate session policy control to an accountability partner or guardian via a secure cryptographic PIN.",
            fontSize = 13.sp,
            color = LockinGrayText
        )

        // Status Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(LockinCardDark)
                .border(1.dp, if (isAdminEnabled) LockinCyan.copy(alpha = 0.4f) else LockinBorder, RoundedCornerShape(22.dp))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ADMINISTRATOR LOCK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = LockinGrayText
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isAdminEnabled) LockinCyanSubtle else LockinSubtle)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (isAdminEnabled) "Configured" else "Unrestricted",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isAdminEnabled) LockinCyan else LockinGrayText
                        )
                    }
                }

                Text(
                    text = if (isAdminEnabled)
                        "Settings and active Strict Mode sessions require the administrator's salted SHA-256 PIN to modify or stop."
                    else
                        "No admin PIN is configured. You have unrestricted access to modify and pause all rules.",
                    color = LockinWhite,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                if (!isAdminEnabled) {
                    Button(
                        onClick = {
                            errorMessage = null
                            pinInput = ""
                            pinConfirmInput = ""
                            showPinSetupDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LockinWhite,
                            contentColor = LockinBlack
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text("Configure Admin PIN", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            disableError = false
                            disablePinInput = ""
                            showDisableDialog = true
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LockinCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LockinCyan.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text("Disable Admin Lock", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                }
            }
        }

        // Security architecture note
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(LockinCardDark)
                .border(1.dp, LockinBorder, RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "CRYPTOGRAPHIC SECURITY",
                    color = LockinWhite,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "• PINs are hashed on-device using salted SHA-256 and stored in private sandboxed storage.\n" +
                           "• We deliberately avoid simulated remote-control features without mutual TLS and authenticated backend servers.",
                    color = LockinGrayText,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }

    // Pin Setup Dialog
    if (showPinSetupDialog) {
        AlertDialog(
            onDismissRequest = { showPinSetupDialog = false },
            containerColor = LockinCardDark,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Set Admin PIN", color = LockinWhite, fontWeight = FontWeight.SemiBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Have your trusted partner enter a 4-6 digit numeric secret PIN.", color = LockinGrayText, fontSize = 13.sp)
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 6) pinInput = it },
                        label = { Text("New PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LockinWhite,
                            unfocusedTextColor = LockinWhite,
                            focusedBorderColor = LockinCyan
                        )
                    )
                    OutlinedTextField(
                        value = pinConfirmInput,
                        onValueChange = { if (it.length <= 6) pinConfirmInput = it },
                        label = { Text("Confirm PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LockinWhite,
                            unfocusedTextColor = LockinWhite,
                            focusedBorderColor = LockinCyan
                        )
                    )
                    if (errorMessage != null) {
                        Text(errorMessage!!, color = LockinCyan, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pinInput.length < 4) {
                        errorMessage = "PIN must be at least 4 digits"
                    } else if (pinInput != pinConfirmInput) {
                        errorMessage = "PINs do not match"
                    } else {
                        onSetPin(pinInput)
                        showPinSetupDialog = false
                    }
                }) {
                    Text("Confirm", color = LockinWhite, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinSetupDialog = false }) {
                    Text("Cancel", color = LockinGrayText)
                }
            }
        )
    }

    // Disable Dialog
    if (showDisableDialog) {
        AlertDialog(
            onDismissRequest = { showDisableDialog = false },
            containerColor = LockinCardDark,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Admin Authentication", color = LockinWhite, fontWeight = FontWeight.SemiBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter current Admin PIN to disable protection.", color = LockinGrayText, fontSize = 13.sp)
                    OutlinedTextField(
                        value = disablePinInput,
                        onValueChange = { disablePinInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = disableError,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = LockinWhite,
                            unfocusedTextColor = LockinWhite,
                            focusedBorderColor = LockinCyan
                        )
                    )
                    if (disableError) {
                        Text("Incorrect PIN entered.", color = LockinCyan, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = onDisableAdmin(disablePinInput)
                    if (ok) {
                        showDisableDialog = false
                    } else {
                        disableError = true
                    }
                }) {
                    Text("Disable", color = LockinWhite, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisableDialog = false }) {
                    Text("Cancel", color = LockinGrayText)
                }
            }
        )
    }
}

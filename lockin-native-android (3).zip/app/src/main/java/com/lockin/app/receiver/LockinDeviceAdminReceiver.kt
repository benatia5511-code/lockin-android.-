package com.lockin.app.receiver

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import com.lockin.app.LockinApplication

/**
 * Genuine Android Enterprise & Device Policy Receiver.
 *
 * TECHNICAL HONESTY & OS BOUNDARIES:
 * 1. Standard Device Administrator (Consumer mode):
 *    Android does NOT allow ordinary device admins to block uninstallation.
 *    It can only provide onDisableRequested() warning prompts and screen lock policies.
 *
 * 2. Device Owner (Enterprise mode):
 *    If provisioned via ADB (e.g. adb shell dpm set-device-owner com.lockin.app/.receiver.LockinDeviceAdminReceiver),
 *    this receiver gains true OS-level power to call DevicePolicyManager.setUninstallBlocked().
 *    When enabled, the OS completely grays out the "Uninstall" button across the entire system.
 */
class LockinDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "LOCKIN Device Administrator enabled.")
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        val repository = LockinApplication.instance.repository
        val session = repository.currentSession.value

        if (session != null && session.isActive && !session.isExpired && session.isStrictMode) {
            return "WARNING: An active LOCKIN Strict Mode session is enforcing. Disabling device admin will violate your commitment."
        }
        return "Deactivating LOCKIN Device Admin removes strict uninstall guardrails."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "LOCKIN Device Administrator disabled.")
    }

    companion object {
        private const val TAG = "LockinDeviceAdmin"

        fun getComponentName(context: Context): ComponentName {
            return ComponentName(context, LockinDeviceAdminReceiver::class.java)
        }

        /**
         * Checks whether LOCKIN is elevated to Device Owner status on this device.
         */
        fun isDeviceOwner(context: Context): Boolean {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            return dpm?.isDeviceOwnerApp(context.packageName) == true
        }

        /**
         * Sets true OS uninstall lock if provisioned as Device Owner.
         */
        fun setUninstallBlockedIfDeviceOwner(context: Context, blocked: Boolean) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return
            val component = getComponentName(context)
            if (dpm.isDeviceOwnerApp(context.packageName)) {
                try {
                    dpm.setUninstallBlocked(component, context.packageName, blocked)
                    Log.i(TAG, "Device Owner: setUninstallBlocked($blocked) succeeded.")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to setUninstallBlocked", e)
                }
            }
        }
    }
}

package com.lockin.app.ui.screens

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.receiver.LockinDeviceAdminReceiver
import com.lockin.app.service.LockinAccessibilityService
import com.lockin.app.ui.theme.*

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Real system permission checks querying actual OS settings
    val isAccessibilityGranted = LockinAccessibilityService.isEnabledInSettings(context)

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isBatteryOptimized = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
    } else true

    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    val adminComponent = LockinDeviceAdminReceiver.getComponentName(context)
    val isDeviceAdminActive = dpm?.isAdminActive(adminComponent) == true
    val isDeviceOwnerActive = LockinDeviceAdminReceiver.isDeviceOwner(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LockinBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SETTINGS & PERMISSIONS",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
            color = LockinWhite
        )

        Text(
            text = "Audit real-time system privileges and configure OEM background guardrails.",
            fontSize = 13.sp,
            color = LockinGrayText
        )

        // Permission Diagnostic List
        Text(
            text = "CORE PERMISSION HEALTHCHECK",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = LockinGrayText
        )

        // 1. Accessibility Service
        PermissionTile(
            title = "Accessibility Service",
            subtitle = "Detects foreground app transitions to trigger lock screens immediately.",
            isGranted = isAccessibilityGranted,
            actionLabel = "GRANT IN SETTINGS",
            onAction = {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        )

        // 2. Battery Optimization Exemption
        PermissionTile(
            title = "Unrestricted Battery",
            subtitle = "Prevents aggressive Android OEM power management from killing blocker timers.",
            isGranted = isBatteryOptimized,
            actionLabel = "DISABLE BATTERY OPTIMIZATION",
            onAction = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:${context.packageName}")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                }
            }
        )

        // 3. Device Administrator
        PermissionTile(
            title = "Device Administrator",
            subtitle = "Protects active Strict Mode sessions from unauthorized app uninstallation.",
            isGranted = isDeviceAdminActive,
            actionLabel = "ACTIVATE DEVICE ADMIN",
            onAction = {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Protects active strict sessions from accidental or impulsive deletion.")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        )

        // 4. Usage Access
        PermissionTile(
            title = "Usage Stats Access",
            subtitle = "Secondary telemetry engine to confirm screen time and time-in-app.",
            isGranted = true,
            actionLabel = "OPEN USAGE SETTINGS",
            onAction = {
                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        )

        // How to restore protection guide
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LockinCardDark, RoundedCornerShape(16.dp))
                .border(1.dp, LockinBorder, RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "RESTORING PROTECTION AFTER PERMISSIONS REVOCATION",
                    color = LockinWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Certain aggressive phone brands (Xiaomi MIUI/HyperOS, Samsung OneUI, OnePlus OxygenOS, Huawei EMUI) frequently sleep or disable Accessibility services when idle.\n\n" +
                           "To fix persistent shutdowns:\n" +
                           "1. Pin LOCKIN in your Android Recent Apps overview screen.\n" +
                           "2. Enable 'Autostart' or 'Background Autostart' in your phone's battery settings.\n" +
                           "3. Set Battery Usage to 'Unrestricted' (not Optimized).",
                    color = LockinGrayText,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun PermissionTile(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(LockinCardDark)
            .border(1.dp, if (isGranted) LockinBorder else LockinCyan.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    color = LockinWhite
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isGranted) LockinCyanSubtle else LockinSubtle)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isGranted) "Enabled" else "Action Required",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isGranted) LockinCyan else LockinGrayText
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = LockinGrayText,
                lineHeight = 17.sp
            )
            if (!isGranted) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onAction,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LockinCyan),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LockinCyan.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(actionLabel, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

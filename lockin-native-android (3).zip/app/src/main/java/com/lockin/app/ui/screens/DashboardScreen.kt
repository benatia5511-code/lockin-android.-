package com.lockin.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.model.BlockSession
import com.lockin.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun DashboardScreen(
    currentSession: BlockSession?,
    selectedAppCount: Int,
    blockedDomainCount: Int,
    isStrictMode: Boolean,
    isAccessibilityEnabled: Boolean,
    onRequestAccessibilityPermission: () -> Unit,
    onStartSessionClick: (durationMinutes: Int) -> Unit,
    onStopSessionClick: () -> Unit,
    onNavigateToApps: () -> Unit,
    onNavigateToWebsites: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val scrollState = rememberScrollState()

    var remainingTimeText by remember { mutableStateOf("00:00:00") }
    var progressFraction by remember { mutableStateOf(1f) }

    // Selected duration in minutes when ready (defaults to 60 mins = 1 hour)
    var selectedDurationMinutes by remember { mutableStateOf(60) }
    val durationPresets = listOf(
        30 to "30m",
        60 to "1h",
        120 to "2h",
        480 to "8h",
        1440 to "24h"
    )

    val sessionStatus: String = when {
        currentSession == null -> "Ready"
        currentSession.isExpired -> "Completed"
        currentSession.isActive -> "Active"
        else -> "Ready"
    }

    LaunchedEffect(currentSession) {
        while (currentSession != null && currentSession.isActive && !currentSession.isExpired) {
            val remaining = currentSession.remainingMillis
            val total = (currentSession.durationMinutes.toLong() * 60 * 1000).coerceAtLeast(1L)
            progressFraction = (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)

            val hours = remaining / 3600000
            val minutes = (remaining % 3600000) / 60000
            val seconds = (remaining % 60000) / 1000
            remainingTimeText = "%02d:%02d:%02d".format(hours, minutes, seconds)
            delay(1000)
        }
        if (currentSession == null || currentSession.isExpired) {
            remainingTimeText = "00:00:00"
            progressFraction = 0f
        }
    }

    // Format ready duration display
    val readyTimerText = remember(selectedDurationMinutes) {
        val hours = selectedDurationMinutes / 60
        val mins = selectedDurationMinutes % 60
        "%02d:%02d:00".format(hours, mins)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LockinBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Small, understated LOCKIN title & status indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LOCKIN",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 3.sp,
                    color = LockinWhite
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "DIGITAL WELLBEING",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.2.sp,
                    color = LockinGrayText
                )
            }

            // Minimalist Status Indicator Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        when (sessionStatus) {
                            "Active" -> LockinCyanSubtle
                            else -> LockinCardDark
                        }
                    )
                    .border(
                        1.dp,
                        when (sessionStatus) {
                            "Active" -> LockinCyan.copy(alpha = 0.4f)
                            else -> LockinBorder
                        },
                        RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                when (sessionStatus) {
                                    "Active" -> LockinCyan
                                    "Completed" -> LockinGrayText
                                    else -> LockinCyan.copy(alpha = 0.8f)
                                },
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = sessionStatus,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = when (sessionStatus) {
                            "Active" -> LockinCyan
                            "Completed" -> LockinGrayText
                            else -> LockinWhite
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Accessibility Advisory (if permission required)
        if (!isAccessibilityEnabled) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(LockinCardDark)
                    .border(1.dp, LockinBorder, RoundedCornerShape(22.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(LockinCyan, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ACCESSIBILITY SETUP REQUIRED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = LockinWhite
                        )
                    }
                    Text(
                        text = "Android requires Accessibility access to detect when blocked applications open. Enable LOCKIN in system settings to protect your focus.",
                        fontSize = 12.sp,
                        color = LockinGrayText,
                        lineHeight = 17.sp
                    )
                    OutlinedButton(
                        onClick = onRequestAccessibilityPermission,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LockinCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LockinCyan.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Open Settings", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // 2 & 3. Centered Timer & Status Card (Refined Graphite Wellbeing Aesthetic)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(LockinCardDark)
                .border(1.dp, LockinBorder, RoundedCornerShape(28.dp))
                .padding(vertical = 36.dp, horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = when (sessionStatus) {
                        "Active" -> "FOCUS TIME REMAINING"
                        "Completed" -> "SESSION COMPLETED"
                        else -> "SESSION DURATION"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.sp,
                    color = LockinGrayText
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Beautiful Digital Countdown Timer
                Text(
                    text = if (currentSession != null && currentSession.isActive) remainingTimeText else readyTimerText,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Light,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 2.sp,
                    color = LockinWhite
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Subtle Progress Line or Subtitle
                if (currentSession != null && currentSession.isActive) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.65f)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(LockinSubtle)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progressFraction)
                                .fillMaxHeight()
                                .background(LockinCyan)
                        )
                    }
                } else {
                    Text(
                        text = "Deep work and quiet digital habit protection.",
                        fontSize = 12.sp,
                        color = LockinGrayText.copy(alpha = 0.85f),
                        textAlign = TextAlign.Center
                    )
                }

                if (currentSession?.isStrictMode == true) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(LockinCyanSubtle)
                            .border(1.dp, LockinCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Strict Commitment Active",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = LockinCyan
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 6a. Easy Access to Duration Selection (when not active)
        if (currentSession == null || currentSession.isExpired) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(LockinCardDark)
                    .border(1.dp, LockinBorder, RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "SESSION DURATION",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.5.sp,
                    color = LockinGrayText
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    durationPresets.forEach { (mins, label) ->
                        val isSelected = selectedDurationMinutes == mins
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) LockinWhite else LockinSurface
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) LockinWhite else LockinBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedDurationMinutes = mins },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (isSelected) LockinBlack else LockinGrayText
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 4. Refined Primary Button to Start a Focus Session
        if (currentSession == null || currentSession.isExpired) {
            Button(
                onClick = { onStartSessionClick(selectedDurationMinutes) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = LockinWhite,
                    contentColor = LockinBlack
                )
            ) {
                val label = durationPresets.find { it.first == selectedDurationMinutes }?.second ?: "${selectedDurationMinutes}m"
                Text(
                    text = "Start Focus Session ($label)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
            }
        } else {
            OutlinedButton(
                onClick = onStopSessionClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (currentSession.isStrictMode) LockinGrayText else LockinWhite
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (currentSession.isStrictMode) LockinBorder else LockinBorder.copy(alpha = 0.8f)
                )
            ) {
                Text(
                    text = if (currentSession.isStrictMode) "Strict Session (Locked)" else "End Session",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 5. Two Clean Cards for Blocked Applications and Websites
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Applications Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(LockinCardDark)
                    .border(1.dp, LockinBorder, RoundedCornerShape(22.dp))
                    .clickable { onNavigateToApps() }
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "APPLICATIONS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.5.sp,
                            color = LockinGrayText
                        )
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(LockinCyan, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "$selectedAppCount",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Normal,
                        color = LockinWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Configured apps",
                        fontSize = 11.sp,
                        color = LockinGrayText
                    )
                }
            }

            // Websites Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(LockinCardDark)
                    .border(1.dp, LockinBorder, RoundedCornerShape(22.dp))
                    .clickable { onNavigateToWebsites() }
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "WEBSITES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.5.sp,
                            color = LockinGrayText
                        )
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(LockinCyan, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "$blockedDomainCount",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Normal,
                        color = LockinWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Filtered domains",
                        fontSize = 11.sp,
                        color = LockinGrayText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 6b. Easy Access to Blocking Settings & Protection Policies Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(LockinCardDark)
                .border(1.dp, LockinBorder, RoundedCornerShape(22.dp))
                .clickable { onNavigateToSettings() }
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BLOCKING SETTINGS & POLICY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 1.5.sp,
                        color = LockinGrayText
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isStrictMode) "Strict Commitment Active • Tap to view" else "Flexible Sessions Allowed • Tap to configure",
                        fontSize = 12.sp,
                        color = if (isStrictMode) LockinCyan else LockinWhite
                    )
                }
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (isStrictMode) LockinCyan else LockinSubtle, CircleShape)
                )
            }
        }
    }
}

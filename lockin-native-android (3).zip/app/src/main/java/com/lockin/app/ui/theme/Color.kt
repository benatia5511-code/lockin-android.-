package com.lockin.app.ui.theme

import androidx.compose.ui.graphics.Color

// Refined, subtle, futuristic digital wellbeing palette
val LockinBlack = Color(0xFF0D0E12)         // Deep dark graphite
val LockinSurface = Color(0xFF14161D)       // Soft charcoal surface
val LockinCardDark = Color(0xFF1A1D25)      // Elegant card background
val LockinCardHover = Color(0xFF222631)     // Elevated hover state
val LockinBorder = Color(0xFF2A2F3C)        // Gentle border
val LockinBorderSubtle = Color(0xFF1E222D)  // Understated hairline divider
val LockinWhite = Color(0xFFF1F3F7)         // Soft off-white text
val LockinGrayText = Color(0xFF8E95A5)      // Balanced medium-gray text
val LockinSubtle = Color(0xFF313644)        // Low-contrast track / chip

// Subtle muted cyan accents
val LockinCyan = Color(0xFF38B2AC)          // Refined muted cyan accent
val LockinCyanSubtle = Color(0xFF12272A)    // Soft cyan background tint
val LockinCyanGlow = Color(0x2038B2AC)      // Gentle ambient highlight

// Compatibility aliases (mapped to refined cyan palette)
val LockinRed = LockinCyan
val LockinRedGlow = LockinCyanGlow
val LockinRedSubtle = LockinCyanSubtle

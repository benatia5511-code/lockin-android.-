package com.lockin.app.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.lockin.app.LockinApplication
import com.lockin.app.ui.BlockedOverlayActivity

class LockinAccessibilityService : AccessibilityService() {

    private var lastInterceptTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val eventType = event.eventType
        if (eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            return
        }

        val packageName = event.packageName?.toString() ?: return

        // Ignore our own package
        if (packageName == this.packageName) return

        val repository = LockinApplication.instance.repository
        val currentSession = repository.currentSession.value ?: return

        // Verify session is active and not expired
        if (!currentSession.isActive || currentSession.isExpired) {
            // Automatically clean up expired session
            if (currentSession.isActive && currentSession.isExpired) {
                repository.stopSession()
            }
            return
        }

        val now = SystemClock.elapsedRealtime()

        // 1. Direct App Blocking Mechanism
        if (currentSession.blockedPackages.contains(packageName)) {
            if (now - lastInterceptTime > 600) {
                lastInterceptTime = now
                launchBlockOverlay(packageName, "App Restriction: $packageName")
            }
            return
        }

        // 2. Browser URL Inspection (Pairs with VPN DNS sinkhole for DoH bypass defense)
        if (currentSession.blockedDomains.isNotEmpty() && isBrowserPackage(packageName)) {
            val rootNode = rootInActiveWindow
            if (rootNode != null) {
                val detectedDomain = findBlockedDomainInNode(rootNode, currentSession.blockedDomains)
                if (detectedDomain != null) {
                    if (now - lastInterceptTime > 800) {
                        lastInterceptTime = now
                        launchBlockOverlay(packageName, "Domain Filtered: $detectedDomain")
                    }
                    return
                }
            }
        }

        // 3. Strict Mode Self-Protection
        // If Strict Mode is on, prevent bypassing by disabling LOCKIN permissions or clearing data
        if (currentSession.isStrictMode) {
            if (packageName == "com.android.settings") {
                val rootNode = rootInActiveWindow ?: return
                // Check if user is inside LOCKIN App Info or Accessibility settings attempting disable
                val appTitle = rootNode.findAccessibilityNodeInfosByText("LOCKIN")
                val uninstallText = rootNode.findAccessibilityNodeInfosByText("Uninstall")
                val forceStopText = rootNode.findAccessibilityNodeInfosByText("Force stop")

                if (appTitle.isNotEmpty() && (uninstallText.isNotEmpty() || forceStopText.isNotEmpty())) {
                    if (now - lastInterceptTime > 800) {
                        lastInterceptTime = now
                        performGlobalAction(GLOBAL_ACTION_HOME)
                    }
                }
            }
        }
    }

    private fun isBrowserPackage(pkg: String): Boolean {
        return pkg == "com.android.chrome" ||
                pkg == "org.mozilla.firefox" ||
                pkg == "com.microsoft.emmx" ||
                pkg == "com.opera.browser" ||
                pkg == "com.brave.browser" ||
                pkg == "com.sec.android.app.sbrowser"
    }

    private fun findBlockedDomainInNode(node: AccessibilityNodeInfo, blockedDomains: Set<String>): String? {
        val text = node.text?.toString()?.lowercase()
        if (text != null) {
            for (domain in blockedDomains) {
                val clean = domain.trim().lowercase()
                if (text.contains(clean)) {
                    return clean
                }
            }
        }

        val childCount = node.childCount
        for (i in 0 until childCount) {
            val child = node.getChild(i) ?: continue
            val found = findBlockedDomainInNode(child, blockedDomains)
            if (found != null) return found
        }
        return null
    }

    private fun launchBlockOverlay(blockedPackage: String, reason: String) {
        // Immediate action: return home to collapse target window
        performGlobalAction(GLOBAL_ACTION_HOME)

        val intent = Intent(this, BlockedOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            putExtra(BlockedOverlayActivity.EXTRA_BLOCKED_PACKAGE, blockedPackage)
            putExtra(BlockedOverlayActivity.EXTRA_BLOCK_REASON, reason)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
    }

    companion object {
        var isRunning = false
            private set

        /**
         * Reliably checks whether this AccessibilityService is enabled in Android OS Settings.
         */
        fun isEnabledInSettings(context: Context): Boolean {
            val expectedComponentName = ComponentName(context, LockinAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServices)
            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()
                val enabledComponent = ComponentName.unflattenFromString(componentNameString)
                if (enabledComponent != null && enabledComponent == expectedComponentName) {
                    return true
                }
            }
            return false
        }
    }
}

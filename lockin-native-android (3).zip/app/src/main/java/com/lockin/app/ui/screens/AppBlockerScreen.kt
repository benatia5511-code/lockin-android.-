package com.lockin.app.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.model.BlockedAppItem
import com.lockin.app.service.LockinAccessibilityService
import com.lockin.app.ui.theme.*

@Composable
fun AppBlockerScreen(
    selectedPackages: Set<String>,
    onTogglePackage: (String) -> Unit,
    onStartSessionWithDuration: (Int) -> Unit
) {
    val context = LocalContext.current
    var selectedDurationMinutes by remember { mutableStateOf(60) }
    var customDurationMinutes by remember { mutableStateOf(45) }
    var isCustomSelected by remember { mutableStateOf(false) }

    val presetDurations = listOf(30, 60, 120, 480, 1440)

    val standardApps = remember {
        listOf(
            BlockedAppItem("com.zhiliaoapp.musically", "TikTok", "Short Video"),
            BlockedAppItem("com.instagram.android", "Instagram", "Social Feed"),
            BlockedAppItem("com.google.android.youtube", "YouTube", "Video Streaming"),
            BlockedAppItem("com.android.chrome", "Google Chrome", "Web Browser"),
            BlockedAppItem("com.reddit.frontpage", "Reddit", "Social Forum"),
            BlockedAppItem("com.twitter.android", "X (Twitter)", "Social Network"),
            BlockedAppItem("com.snapchat.android", "Snapchat", "Messaging"),
            BlockedAppItem("com.netflix.mediaclient", "Netflix", "Entertainment"),
            BlockedAppItem("com.supercell.clashofclans", "Clash of Clans", "Gaming"),
            BlockedAppItem("com.roblox.client", "Roblox", "Gaming")
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LockinBlack)
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Applications",
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                color = LockinWhite
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Choose applications to pause during your focus sessions.",
                fontSize = 13.sp,
                color = LockinGrayText
            )
        }

        // Android Permission Status Notice
        item {
            val accessibilityActive = LockinAccessibilityService.isEnabledInSettings(context)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(LockinCardDark)
                    .border(1.dp, if (accessibilityActive) LockinBorder else LockinCyan.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACCESSIBILITY PROTECTION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = if (accessibilityActive) LockinWhite else LockinCyan
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (accessibilityActive) LockinCyanSubtle else LockinSubtle)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (accessibilityActive) "Active" else "Action Required",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (accessibilityActive) LockinCyan else LockinGrayText
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Android requires Accessibility Service permission to observe when restricted applications open and gently redirect you back to deep work.",
                        fontSize = 12.sp,
                        color = LockinGrayText,
                        lineHeight = 17.sp
                    )
                    if (!accessibilityActive) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                })
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = LockinCyan),
                            border = androidx.compose.foundation.BorderStroke(1.dp, LockinCyan.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Enable Permission in Settings", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        // Duration Presets Selector (30m, 1h, 2h, 8h, 24h, custom)
        item {
            Text(
                text = "SESSION DURATION",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp,
                color = LockinGrayText
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presetDurations.forEach { mins ->
                    val label = when (mins) {
                        30 -> "30m"
                        60 -> "1h"
                        120 -> "2h"
                        480 -> "8h"
                        1440 -> "24h"
                        else -> "${mins}m"
                    }
                    val isSelected = !isCustomSelected && selectedDurationMinutes == mins

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) LockinWhite else LockinCardDark)
                            .border(1.dp, if (isSelected) LockinWhite else LockinBorder, RoundedCornerShape(14.dp))
                            .clickable {
                                isCustomSelected = false
                                selectedDurationMinutes = mins
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 12.sp,
                            color = if (isSelected) LockinBlack else LockinWhite
                        )
                    }
                }

                // Custom duration button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isCustomSelected) LockinWhite else LockinCardDark)
                        .border(1.dp, if (isCustomSelected) LockinWhite else LockinBorder, RoundedCornerShape(14.dp))
                        .clickable { isCustomSelected = true }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Custom",
                        fontWeight = if (isCustomSelected) FontWeight.SemiBold else FontWeight.Normal,
                        fontSize = 11.sp,
                        color = if (isCustomSelected) LockinBlack else LockinWhite
                    )
                }
            }

            if (isCustomSelected) {
                Spacer(modifier = Modifier.height(12.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(LockinCardDark)
                        .border(1.dp, LockinBorder, RoundedCornerShape(18.dp))
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Custom Timer", color = LockinWhite, fontSize = 13.sp)
                        Text("$customDurationMinutes minutes", color = LockinCyan, fontWeight = FontWeight.Medium)
                    }
                    Slider(
                        value = customDurationMinutes.toFloat(),
                        onValueChange = { customDurationMinutes = it.toInt() },
                        valueRange = 5f..360f,
                        colors = SliderDefaults.colors(
                            thumbColor = LockinWhite,
                            activeTrackColor = LockinCyan,
                            inactiveTrackColor = LockinSubtle
                        )
                    )
                }
            }
        }

        item {
            Text(
                text = "TARGET APPLICATIONS (${selectedPackages.size} SELECTED)",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp,
                color = LockinGrayText
            )
        }

        // List of target apps
        items(standardApps) { app ->
            val isSelected = selectedPackages.contains(app.packageName)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(LockinCardDark)
                    .border(
                        1.dp,
                        if (isSelected) LockinCyan.copy(alpha = 0.4f) else LockinBorder,
                        RoundedCornerShape(18.dp)
                    )
                    .clickable { onTogglePackage(app.packageName) }
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = app.appName,
                            fontWeight = FontWeight.Medium,
                            fontSize = 15.sp,
                            color = LockinWhite
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "${app.category} • ${app.packageName}",
                            fontSize = 11.sp,
                            color = LockinGrayText
                        )
                    }

                    Switch(
                        checked = isSelected,
                        onCheckedChange = { onTogglePackage(app.packageName) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = LockinWhite,
                            checkedTrackColor = LockinCyan,
                            uncheckedThumbColor = LockinGrayText,
                            uncheckedTrackColor = LockinSubtle
                        )
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    val finalDuration = if (isCustomSelected) customDurationMinutes else selectedDurationMinutes
                    onStartSessionWithDuration(finalDuration)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = LockinWhite,
                    contentColor = LockinBlack
                ),
                enabled = selectedPackages.isNotEmpty()
            ) {
                Text(
                    text = "Apply Focus to Selected Apps",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

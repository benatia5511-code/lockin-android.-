package com.lockin.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.lockin.app.data.LockinRepository

class LockinApplication : Application() {

    lateinit var repository: LockinRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        repository = LockinRepository(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_PROTECTION,
                "LOCKIN Active Protection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows ongoing block status and countdown timer"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID_PROTECTION = "lockin_protection_channel"
        lateinit var instance: LockinApplication
            private set
    }
}

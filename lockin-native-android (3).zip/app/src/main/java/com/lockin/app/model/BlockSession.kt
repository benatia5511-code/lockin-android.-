package com.lockin.app.model

data class BlockSession(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "Focus Session",
    val startTimeMillis: Long = System.currentTimeMillis(),
    val endTimeMillis: Long = System.currentTimeMillis() + (30 * 60 * 1000),
    val durationMinutes: Int = 30,
    val blockedPackages: Set<String> = emptySet(),
    val blockedDomains: Set<String> = emptySet(),
    val isStrictMode: Boolean = false,
    val isAdminLocked: Boolean = false,
    val isActive: Boolean = true
) {
    val remainingMillis: Long
        get() = (endTimeMillis - System.currentTimeMillis()).coerceAtLeast(0L)

    val isExpired: Boolean
        get() = System.currentTimeMillis() >= endTimeMillis
}

data class BlockedAppItem(
    val packageName: String,
    val appName: String,
    val category: String = "Distraction",
    val isDefaultSelected: Boolean = false
)

data class BlockedDomainItem(
    val domain: String,
    val category: String = "Social Media",
    val isCustom: Boolean = false
)

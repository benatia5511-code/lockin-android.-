package com.lockin.app.ui.screens

import android.net.VpnService
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.model.BlockedDomainItem
import com.lockin.app.service.LockinVpnFilterService
import com.lockin.app.ui.theme.*

@Composable
fun WebsiteBlockerScreen(
    blockedDomains: Set<String>,
    onToggleDomain: (String) -> Unit,
    onAddCustomDomain: (String) -> Unit
) {
    val context = LocalContext.current
    var newDomainInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Social", "Entertainment", "Custom")

    val catalog = remember {
        listOf(
            BlockedDomainItem("tiktok.com", "Social"),
            BlockedDomainItem("instagram.com", "Social"),
            BlockedDomainItem("youtube.com", "Entertainment"),
            BlockedDomainItem("x.com", "Social"),
            BlockedDomainItem("reddit.com", "Social"),
            BlockedDomainItem("twitch.tv", "Entertainment"),
            BlockedDomainItem("netflix.com", "Entertainment"),
            BlockedDomainItem("discord.com", "Social")
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LockinBlack)
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Websites",
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                color = LockinWhite
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Filter distracting domains across browsers via local DNS loopback.",
                fontSize = 13.sp,
                color = LockinGrayText
            )
        }

        // ARCHITECTURAL HONESTY & LIMITATION CARD
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(LockinCardDark)
                    .border(1.dp, LockinBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DNS SINKHOLE & PRIVACY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = LockinWhite
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (LockinVpnFilterService.isRunning) LockinCyanSubtle else LockinSubtle)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (LockinVpnFilterService.isRunning) "Filter Active" else "Standby",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (LockinVpnFilterService.isRunning) LockinCyan else LockinGrayText
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Standard port 53 DNS queries are answered with 0.0.0.0 on-device without passing through external proxy servers.\n" +
                               "• Browser Notice: Browsers with 'Secure DNS (DoH)' enabled bypass system DNS. LOCKIN pairs this loopback with Accessibility URL detection to safeguard browsing.",
                        fontSize = 12.sp,
                        color = LockinGrayText,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Add Custom Domain Form
        item {
            Text(
                text = "ADD DOMAIN",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp,
                color = LockinGrayText
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newDomainInput,
                    onValueChange = { newDomainInput = it.lowercase().trim() },
                    placeholder = { Text("e.g. reddit.com", color = LockinGrayText, fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = LockinWhite,
                        unfocusedTextColor = LockinWhite,
                        focusedBorderColor = LockinCyan,
                        unfocusedBorderColor = LockinBorder,
                        focusedContainerColor = LockinCardDark,
                        unfocusedContainerColor = LockinCardDark
                    )
                )

                Button(
                    onClick = {
                        if (newDomainInput.contains(".")) {
                            onAddCustomDomain(newDomainInput)
                            newDomainInput = ""
                        }
                    },
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LockinWhite,
                        contentColor = LockinBlack
                    ),
                    enabled = newDomainInput.contains(".")
                ) {
                    Text("Add", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Category Filter Chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { cat ->
                    val isSel = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) LockinWhite else LockinCardDark)
                            .border(1.dp, if (isSel) LockinWhite else LockinBorder, RoundedCornerShape(12.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = cat,
                            fontSize = 12.sp,
                            fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (isSel) LockinBlack else LockinWhite
                        )
                    }
                }
            }
        }

        // Domain List
        items(catalog.filter { selectedCategory == "All" || it.category == selectedCategory }) { item ->
            val isBlocked = blockedDomains.contains(item.domain)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(LockinCardDark)
                    .border(
                        1.dp,
                        if (isBlocked) LockinCyan.copy(alpha = 0.4f) else LockinBorder,
                        RoundedCornerShape(18.dp)
                    )
                    .clickable { onToggleDomain(item.domain) }
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = item.domain,
                            fontWeight = FontWeight.Medium,
                            fontSize = 15.sp,
                            color = LockinWhite
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Category: ${item.category}",
                            fontSize = 11.sp,
                            color = LockinGrayText
                        )
                    }

                    Switch(
                        checked = isBlocked,
                        onCheckedChange = { onToggleDomain(item.domain) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = LockinWhite,
                            checkedTrackColor = LockinCyan,
                            uncheckedThumbColor = LockinGrayText,
                            uncheckedTrackColor = LockinSubtle
                        )
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

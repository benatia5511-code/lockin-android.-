package com.lockin.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = LockinWhite,
    onPrimary = LockinBlack,
    secondary = LockinRed,
    onSecondary = LockinWhite,
    background = LockinBlack,
    onBackground = LockinWhite,
    surface = LockinSurface,
    onSurface = LockinWhite,
    surfaceVariant = LockinCardDark,
    onSurfaceVariant = LockinGrayText,
    outline = LockinBorder
)

@Composable
fun LockinTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

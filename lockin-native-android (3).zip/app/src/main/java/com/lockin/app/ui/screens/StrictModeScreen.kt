package com.lockin.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.receiver.LockinDeviceAdminReceiver
import com.lockin.app.ui.theme.*

@Composable
fun StrictModeScreen(
    isStrictMode: Boolean,
    onToggleStrictMode: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val isDeviceOwner = remember { LockinDeviceAdminReceiver.isDeviceOwner(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LockinBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "STRICT MODE",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
            color = LockinWhite
        )

        Text(
            text = "Eliminate impulse cancellation. Once initiated, active sessions cannot be cancelled through the app interface until the countdown expires.",
            fontSize = 13.sp,
            color = LockinGrayText
        )

        // Main Activation Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(if (isStrictMode) LockinRedSubtle else LockinCardDark)
                .border(1.dp, if (isStrictMode) LockinRed else LockinBorder, RoundedCornerShape(20.dp))
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(
                        text = "ENFORCE STRICT COMMITMENT",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isStrictMode) LockinRed else LockinWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isStrictMode)
                            "Cancellation disabled in UI. Accessibility intercepts Settings tampering."
                        else
                            "Standard mode: Sessions can be stopped manually at any time.",
                        fontSize = 12.sp,
                        color = LockinGrayText
                    )
                }

                Switch(
                    checked = isStrictMode,
                    onCheckedChange = onToggleStrictMode,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = LockinWhite,
                        checkedTrackColor = LockinRed,
                        uncheckedThumbColor = LockinGrayText,
                        uncheckedTrackColor = LockinSubtle
                    )
                )
            }
        }

        // Real OS Protections Explanation
        Text(
            text = "ANDROID SECURITY REALITY & UNINSTALL BOUNDARIES",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = LockinGrayText
        )

        // 1. Accessibility Anti-Tamper (Default consumer mode)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LockinCardDark, RoundedCornerShape(16.dp))
                .border(1.dp, LockinBorder, RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "1. CONSUMER MODE: ACCESSIBILITY ANTI-TAMPER",
                    color = LockinWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "• An ordinary Android Device Administrator CANNOT block app uninstallation on modern Android (API 28+).\n" +
                           "• Instead, LOCKIN uses its AccessibilityService: if you open Android Settings -> Apps -> LOCKIN to uninstall or force stop during Strict Mode, the service immediately navigates back to Home.\n" +
                           "• Ordinary Device Admin merely triggers an OS confirmation warning dialog.",
                    color = LockinGrayText,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        // 2. Device Owner Mode (Enterprise mode for true uninstall block)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LockinCardDark, RoundedCornerShape(16.dp))
                .border(1.dp, if (isDeviceOwner) LockinBorder else LockinSubtle, RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "2. ENTERPRISE MODE: TRUE UNINSTALL LOCK",
                        color = if (isDeviceOwner) LockinWhite else LockinGrayText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (isDeviceOwner) "ACTIVE" else "OPTIONAL (ADB)",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (isDeviceOwner) LockinWhite else LockinGrayText
                    )
                }
                Text(
                    text = "• For 100% unbreakable uninstallation protection, Android requires Device Owner mode.\n" +
                           "• When provisioned as Device Owner, LOCKIN calls DevicePolicyManager.setUninstallBlocked(), completely disabling the Android uninstall button at the system level.\n" +
                           "• To activate, run this one-time command via ADB on a PC:\n" +
                           "adb shell dpm set-device-owner com.lockin.app/.receiver.LockinDeviceAdminReceiver",
                    color = LockinGrayText,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        // Limitations Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LockinCardDark, RoundedCornerShape(16.dp))
                .border(1.dp, LockinBorder, RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "HARDWARE & OS BYPASS REALITIES:",
                    color = LockinRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "• Safe Mode Boot: Holding power buttons during boot disables all 3rd party accessibility services on non-MDM Android devices.\n" +
                           "• ADB Command Line: Users with USB Debugging enabled can issue 'adb uninstall' from a connected computer.\n" +
                           "• Factory Reset: Complete device wipe cannot and should not be prevented by a non-enterprise app.",
                    color = LockinGrayText,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

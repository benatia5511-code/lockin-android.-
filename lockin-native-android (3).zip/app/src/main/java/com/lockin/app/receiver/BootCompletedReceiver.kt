package com.lockin.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.lockin.app.data.LockinRepository
import com.lockin.app.service.AppMonitorForegroundService
import com.lockin.app.service.LockinVpnFilterService

/**
 * Genuine Android Boot Receiver.
 * When the phone restarts (BOOT_COMPLETED), this checks if any session is still active
 * and immediately relaunches the blocking foreground service and VPN filter.
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            val repository = LockinRepository(context)
            val session = repository.currentSession.value

            if (session != null && session.isActive && !session.isExpired) {
                // Restore foreground monitor
                val monitorIntent = Intent(context, AppMonitorForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(monitorIntent)
                } else {
                    context.startService(monitorIntent)
                }

                // If website blocking is active, start VPN
                if (session.blockedDomains.isNotEmpty()) {
                    val vpnIntent = Intent(context, LockinVpnFilterService::class.java).apply {
                        this.action = LockinVpnFilterService.ACTION_START
                    }
                    context.startService(vpnIntent)
                }
            }
        }
    }
}

package com.lockin.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lockin.app.LockinApplication
import com.lockin.app.ui.theme.*
import kotlinx.coroutines.delay

class BlockedOverlayActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val blockedPackage = intent.getStringExtra(EXTRA_BLOCKED_PACKAGE) ?: "Blocked App"

        setContent {
            LockinTheme {
                val repository = LockinApplication.instance.repository
                val session by repository.currentSession.collectAsState()

                var remainingTimeFormatted by remember { mutableStateOf("00:00:00") }
                var showAdminPinDialog by remember { mutableStateOf(false) }
                var pinInput by remember { mutableStateOf("") }
                var pinError by remember { mutableStateOf(false) }

                LaunchedEffect(session) {
                    while (session != null && session!!.isActive && !session!!.isExpired) {
                        val millis = session!!.remainingMillis
                        val hours = millis / 3600000
                        val mins = (millis % 3600000) / 60000
                        val secs = (millis % 60000) / 1000
                        remainingTimeFormatted = "%02d:%02d:%02d".format(hours, mins, secs)
                        delay(1000)
                    }
                    if (session == null || session!!.isExpired) {
                        finish()
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = LockinBlack
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Header
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(top = 48.dp)
                        ) {
                            Text(
                                text = "FOCUS MODE",
                                color = LockinCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 3.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Stay in your flow",
                                color = LockinWhite,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Light,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "This application is currently paused to preserve your deep work and attention.",
                                color = LockinGrayText,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }

                        // Center Countdown Widget (Serene Wellbeing Style)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(28.dp))
                                .background(LockinCardDark)
                                .border(1.dp, LockinBorder, RoundedCornerShape(28.dp))
                                .padding(vertical = 40.dp, horizontal = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "TIME REMAINING",
                                    color = LockinGrayText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    letterSpacing = 2.sp
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = remainingTimeFormatted,
                                    color = LockinWhite,
                                    fontSize = 42.sp,
                                    fontWeight = FontWeight.Light,
                                    fontFamily = FontFamily.SansSerif,
                                    letterSpacing = 2.sp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(LockinCyan, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (session?.isStrictMode == true) "Strict Commitment Active" else "Focus Period Enforcing",
                                        color = if (session?.isStrictMode == true) LockinCyan else LockinGrayText,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        // Action Buttons
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Button(
                                onClick = {
                                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                                        addCategory(Intent.CATEGORY_HOME)
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    startActivity(homeIntent)
                                    finish()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = LockinWhite),
                                shape = RoundedCornerShape(27.dp)
                            ) {
                                Text(
                                    text = "RETURN TO HOME",
                                    color = LockinBlack,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    letterSpacing = 1.sp
                                )
                            }

                            if (session?.isAdminLocked == true) {
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { showAdminPinDialog = true },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LockinGrayText)
                                ) {
                                    Text("ADMIN OVERRIDE", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                if (showAdminPinDialog) {
                    AlertDialog(
                        onDismissRequest = {
                            showAdminPinDialog = false
                            pinInput = ""
                            pinError = false
                        },
                        containerColor = LockinCardDark,
                        title = {
                            Text(
                                "ADMIN AUTHENTICATION",
                                color = LockinWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 16.sp
                            )
                        },
                        text = {
                            Column {
                                Text(
                                    "Enter the trusted administrator PIN to unlock early.",
                                    color = LockinGrayText,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                OutlinedTextField(
                                    value = pinInput,
                                    onValueChange = {
                                        pinInput = it
                                        pinError = false
                                    },
                                    singleLine = true,
                                    isError = pinError,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = LockinWhite,
                                        unfocusedTextColor = LockinWhite,
                                        focusedBorderColor = LockinWhite,
                                        unfocusedBorderColor = LockinBorder
                                    )
                                )
                                if (pinError) {
                                    Text(
                                        "Incorrect PIN",
                                        color = LockinRed,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    val success = repository.stopSession(pinInput)
                                    if (success) {
                                        showAdminPinDialog = false
                                        finish()
                                    } else {
                                        pinError = true
                                    }
                                }
                            ) {
                                Text("UNLOCK", color = LockinWhite)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showAdminPinDialog = false }) {
                                Text("CANCEL", color = LockinGrayText)
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onBackPressed() {
        // Redirect to Home when back pressed
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "extra_blocked_package"
        const val EXTRA_BLOCK_REASON = "extra_block_reason"
    }
}

# Add project specific ProGuard rules here.
# Keep Kotlin Coroutines and Compose rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}
-dontwarn java.lang.invoke.MethodHandles$Lookup
